# 历史资料：不作为当前操作依据

现行入口：[复赛状态](../../docs/CURRENT.md)。原文已逐字节收入[档案索引](../../docs/archive/README.md)，ZIP 内路径为 `evidence/20260916/leaderboard_top20.md`。
